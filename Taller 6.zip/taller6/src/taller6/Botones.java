package taller6;

/**
 *
 * @author Esteban
 */
public class Botones {

    private static RecoleccionDatos rec;
    private static DatosPaciente pa[];
    private static int contador;
    public static void main(String[] args) {
        // TODO code application logic here
       rec = new RecoleccionDatos();
       pa = new DatosPaciente[100];
        for (int i = 0; i < 100; i++) {
            pa[i] = new DatosPaciente();
        }
        contador = 0;
        rec.setVisible(true);
    }
    public static void guardar(int co, String ap, String no, String se, String di, String lr, String la, String mc, String me, String fe) {
    pa[contador].setCodigo(co);
    pa[contador].setApellido(ap);
    pa[contador].setNombre(no);
    pa[contador].setSexo(se);
    pa[contador].setDireccion(di);
    pa[contador].setLugarResidencia(lr);
    pa[contador].setLugarAtendido(la);
    pa[contador].setMotivoConsulta(mc);
    pa[contador].setMedico(me);
    pa[contador].setFecha(fe);
    contador ++;
    }
    public static void buscar(String bus){
        for (int j = 0; j < pa.length; j++) {
            if(pa[j].getNombre().equals(bus)){
                rec.cargardatos(pa[j]);
            }
        }
    }
    public static void buscar2(String bus2){
        for (int k = 0; k < pa.length; k++) {
            if(pa[k].getLugarAtendido().equals(bus2)){
                rec.cargardatos2(pa[k]);
            }
        }
    }
    public static void buscar3(String bus3){
        for (int l = 0; l < pa.length; l++) {
            if(pa[l].getMedico().equals(bus3)){
                rec.cargardatos3(pa[l]);
            }
        }
    }
}
